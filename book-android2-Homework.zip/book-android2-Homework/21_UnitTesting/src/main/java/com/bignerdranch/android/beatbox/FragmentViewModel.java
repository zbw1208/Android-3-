package com.bignerdranch.android.beatbox;

import android.databinding.BaseObservable;
import android.databinding.Bindable;
import android.util.Log;
import android.widget.SeekBar;

public class FragmentViewModel extends BaseObservable {
    private BeatBox mBeatBox;

    public FragmentViewModel(BeatBox beatBox) {
        mBeatBox = beatBox;
    }

    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        float rate = progress * 1.0f / 75;
        mBeatBox.setRate(rate);
        notifyChange();
    }

    @Bindable
    public String getRate() {
        String rate = "playback speed " + (int)(mBeatBox.getRate() * 100 );
        return  rate + "%";
    }
}

package com.bignerdranch.android.geoquiz;

import java.io.Serializable;

public class Question implements Serializable {

    private int mTextResId;
    private boolean mAnswerTrue;
    //3.7 挑战练习：禁止一题多答
    //表示是否已回答
    private boolean mAnswer;
    //3.8 是否答对
    private boolean mCorrect;


    public Question(int textResId, boolean answerTrue) {
        this(textResId, answerTrue, false, false);
    }

    public Question(int textResId, boolean answerTrue, boolean answer, boolean correct) {
        mTextResId = textResId;
        mAnswerTrue = answerTrue;
        mAnswer = answer;
        mCorrect = correct;
    }


    public int getTextResId() {
        return mTextResId;
    }

    public void setTextResId(int textResId) {
        mTextResId = textResId;
    }

    public boolean isAnswerTrue() {
        return mAnswerTrue;
    }

    public void setAnswerTrue(boolean answerTrue) {
        mAnswerTrue = answerTrue;
    }

    public boolean isAnswer() {
        return mAnswer;
    }

    public void setAnswer(boolean answer) {
        mAnswer = answer;
    }

    public boolean isCorrect() {
        return mCorrect;
    }

    public void setCorrect(boolean correct) {
        mCorrect = correct;
    }
}

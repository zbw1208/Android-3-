package com.bignerdranch.android.criminalintent;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;

import java.util.UUID;

//10.7 挑战练习：优化 CrimeLab 的表现
public class CrimeActivity extends SingleFragmentActivity {

    private static final String EXTRA_CRIME_POSITION =
            "com.bignerdranch.android.criminalintent.crime_position";

    public static Intent newIntent(Context packageContext, int position) {
        Intent intent = new Intent(packageContext, CrimeActivity.class);
        intent.putExtra(EXTRA_CRIME_POSITION, position);
        return intent;
    }

    @Override
    protected Fragment createFragment() {
        int position = getIntent().getIntExtra(EXTRA_CRIME_POSITION,0);
        return CrimeFragment.newInstance(position);
    }
}

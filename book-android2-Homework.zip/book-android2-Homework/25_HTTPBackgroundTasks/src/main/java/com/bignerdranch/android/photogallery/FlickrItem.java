package com.bignerdranch.android.photogallery;

import com.google.gson.annotations.SerializedName;

import java.util.List;



public class FlickrItem {
    public GalleryItem photos;

    public GalleryItem getPhotos() {
        return photos;
    }

    public void setPhotos(GalleryItem photos) {
        this.photos = photos;
    }

    public static class GalleryItem {

        public List<Photo> photo;

        public List<Photo> getPhoto() {
            return photo;
        }

        public void setPhoto(List<Photo> photo) {
            this.photo = photo;
        }

        public static class Photo {
            public String id;
            public String url_s;

            @SerializedName("title")
            public String mCaption;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getUrl_s() {
                return url_s;
            }

            public void setUrl_s(String url_s) {
                this.url_s = url_s;
            }

            public String getCaption() {
                return mCaption;
            }

            public void setCaption(String caption) {
                mCaption = caption;
            }

            @Override
            public String toString() {
                return mCaption;
            }
        }

    }
}

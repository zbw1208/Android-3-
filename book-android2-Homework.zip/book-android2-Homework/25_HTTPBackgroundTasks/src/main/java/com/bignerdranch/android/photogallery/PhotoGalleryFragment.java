package com.bignerdranch.android.photogallery;

import android.graphics.Point;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class PhotoGalleryFragment extends Fragment {

    private static final String TAG = "PhotoGalleryFragment";

    private RecyclerView mPhotoRecyclerView;
    private  List<FlickrItem.GalleryItem.Photo> mItems = new ArrayList<>();
    private int mPage = 0;
    private GridLayoutManager mGridLayoutManager;

    public static PhotoGalleryFragment newInstance() {
        return new PhotoGalleryFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        new FetchItemsTask().execute();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_photo_gallery, container, false);

        mPhotoRecyclerView = (RecyclerView) v.findViewById(R.id.photo_recycler_view);
        mGridLayoutManager = new GridLayoutManager(getActivity(), 3);
        mPhotoRecyclerView.setLayoutManager(mGridLayoutManager);
        //增加滚动监听
        mPhotoRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener(){
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                int lastVisibleItem = mGridLayoutManager.findLastCompletelyVisibleItemPosition();
                int totalItemCount = mGridLayoutManager.getItemCount();

                if (lastVisibleItem == totalItemCount - 1) {
                    new FetchItemsTask().execute();
                    Log.d(TAG, "it's buttom");
                }
            }
        } );
        //动态计算列数
        mPhotoRecyclerView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Point point = new Point();
                getActivity().getWindowManager().getDefaultDisplay().getSize(point);
                int col = point.x / 200;
                mPhotoRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), col));
                setupAdapter();
                mPhotoRecyclerView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });
        return v;
    }

    private void setupAdapter() {
        if (isAdded()) {
            mPhotoRecyclerView.setAdapter(new PhotoAdapter(mItems));
        }
    }

    private class PhotoHolder extends RecyclerView.ViewHolder {
        private TextView mTitleTextView;

        public PhotoHolder(View itemView) {
            super(itemView);

            mTitleTextView = (TextView) itemView;
        }

        public void bindGalleryItem(FlickrItem.GalleryItem.Photo item) {
            mTitleTextView.setText(item.toString());
        }
    }

    private class PhotoAdapter extends RecyclerView.Adapter<PhotoHolder> {

        private List<FlickrItem.GalleryItem.Photo> mGalleryItems;

        public PhotoAdapter(List<FlickrItem.GalleryItem.Photo> galleryItems) {
            mGalleryItems = galleryItems;
        }

        @Override
        public PhotoHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
            TextView textView = new TextView(getActivity());
            return new PhotoHolder(textView);
        }

        @Override
        public void onBindViewHolder(PhotoHolder photoHolder, int position) {
            FlickrItem.GalleryItem.Photo photo = mGalleryItems.get(position);
            photoHolder.bindGalleryItem(photo);
        }

        @Override
        public int getItemCount() {
            return mGalleryItems.size();
        }
    }

    private class FetchItemsTask extends AsyncTask<Void,Void,FlickrItem> {
        @Override
        protected FlickrItem doInBackground(Void... params) {
            mPage++;
            return new FlickrFetchr().fetchItems(mPage);
        }

        @Override
        protected void onPostExecute(FlickrItem flickrItem) {
            List<FlickrItem.GalleryItem.Photo> items = flickrItem.getPhotos().getPhoto();
            for (FlickrItem.GalleryItem.Photo item : items) {
                mItems.add(item);
            }
            Log.d(TAG, "onPostExecute: " + mItems.size());
            setupAdapter();
        }

    }
}

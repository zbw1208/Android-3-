package com.bignerdranch.android.criminalintent;

public interface ItemTouchHelperAdapter {
    //数据交换
    void OnItemMove(int fromPosition, int toPosition);

    //数据删除
    void onItemDissmiss(int position);
}
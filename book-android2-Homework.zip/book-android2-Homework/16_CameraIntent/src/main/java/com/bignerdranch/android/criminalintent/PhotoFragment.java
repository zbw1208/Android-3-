package com.bignerdranch.android.criminalintent;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;


public class PhotoFragment extends DialogFragment {
    public static final String ARG_PATH = "path";
    private ImageView mImageView;

    public static PhotoFragment newInstance(String path) {
        Bundle args = new Bundle();
        args.putString(ARG_PATH, path);
        PhotoFragment fragment = new PhotoFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        View v = LayoutInflater.from(getActivity())
                .inflate(R.layout.dialog_photo, null);
        mImageView = v.findViewById(R.id.image_view);
        String path = getArguments().getString(ARG_PATH);
        Bitmap bitmap = BitmapFactory.decodeFile(path);
        mImageView.setImageBitmap(bitmap);
        return new AlertDialog.Builder(getActivity())
                .setTitle(R.string.show_photo_title)
                .setView(v)
                .setPositiveButton(android.R.string.ok, null)
                .create();
    }
}

package com.bignerdranch.android.geoquiz;

import java.io.Serializable;

public class Question implements Serializable {

    private int mTextResId;
    private boolean mAnswerTrue;
    //5.5 挑战练习：堵住漏洞
    private boolean mCheat;

    public Question(int textResId, boolean answerTrue) {
        this(textResId, answerTrue, false);
    }

    public Question(int textResId, boolean answerTrue, boolean cheat) {
        mTextResId = textResId;
        mAnswerTrue = answerTrue;
        mCheat = cheat;
    }

    public int getTextResId() {
        return mTextResId;
    }

    public void setTextResId(int textResId) {
        mTextResId = textResId;
    }

    public boolean isAnswerTrue() {
        return mAnswerTrue;
    }

    public void setAnswerTrue(boolean answerTrue) {
        mAnswerTrue = answerTrue;
    }

    public boolean isCheat() {
        return mCheat;
    }

    public void setCheat(boolean cheat) {
        mCheat = cheat;
    }
}
